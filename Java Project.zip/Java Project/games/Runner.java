package Farahpu;

public class Runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TicTacToe tictactoe = new TicTacToe();

	}

}
